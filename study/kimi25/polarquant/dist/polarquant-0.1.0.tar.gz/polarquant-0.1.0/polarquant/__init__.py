"""
PolarQuant: Lossless Quantization via Polar Transformation

A Python implementation of the PolarQuant algorithm for high-dimensional vector quantization.
Based on Google Research's paper on polar coordinate transformation for KV cache compression.

Key Features:
- Random orthogonal rotation for distribution normalization
- Polar coordinate transformation (radius + angles)
- Lloyd-Max quantization optimized for Beta distribution
- Zero metadata overhead
- Near-lossless compression
"""

from .core import PolarQuant, PolarQuantConfig, PolarQuantBatch
from .utils import (
    random_orthogonal_matrix,
    cartesian_to_polar,
    polar_to_cartesian,
    lloyd_max_quantize,
    lloyd_max_dequantize,
)

__version__ = "0.1.0"
__all__ = [
    "PolarQuant",
    "PolarQuantConfig",
    "PolarQuantBatch",
    "random_orthogonal_matrix",
    "cartesian_to_polar",
    "polar_to_cartesian",
    "lloyd_max_quantize",
    "lloyd_max_dequantize",
]
