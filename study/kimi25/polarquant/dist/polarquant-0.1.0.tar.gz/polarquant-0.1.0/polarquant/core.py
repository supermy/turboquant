"""
Core PolarQuant implementation.

This module implements the main PolarQuant algorithm for lossless quantization
of high-dimensional vectors using polar coordinate transformation.
"""

import numpy as np
from dataclasses import dataclass
from typing import Optional, Tuple, List
import pickle

from .utils import (
    random_orthogonal_matrix,
    cartesian_to_polar,
    polar_to_cartesian,
    compute_lloyd_max_centroids,
    lloyd_max_quantize,
    lloyd_max_dequantize,
    beta_distribution_params,
)


@dataclass
class PolarQuantConfig:
    """Configuration for PolarQuant quantization.
    
    Attributes:
        dimension: Vector dimension (d)
        radius_bits: Number of bits for radius quantization (default: 8)
        angle_bits: Number of bits for angle quantization (default: 4)
        use_hadamard: Use Hadamard rotation instead of random orthogonal (default: False)
        seed: Random seed for reproducibility (default: 42)
    """
    dimension: int
    radius_bits: int = 8
    angle_bits: int = 4
    use_hadamard: bool = False
    seed: int = 42
    
    def __post_init__(self):
        if self.dimension < 2:
            raise ValueError("Dimension must be at least 2")
        if self.radius_bits < 1 or self.radius_bits > 16:
            raise ValueError("radius_bits must be between 1 and 16")
        if self.angle_bits < 1 or self.angle_bits > 16:
            raise ValueError("angle_bits must be between 1 and 16")


class CompressedVector:
    """Represents a compressed vector.
    
    Stores quantized radius and angles as compact integer indices.
    """
    
    def __init__(self, radius_idx: int, angle_indices: np.ndarray, 
                 original_norm: Optional[float] = None):
        self.radius_idx = radius_idx
        self.angle_indices = angle_indices
        self.original_norm = original_norm
    
    def size_bits(self) -> int:
        """Return total size in bits."""
        return 32 + len(self.angle_indices) * 32  # Simplified estimation
    
    def size_bytes(self) -> int:
        """Return total size in bytes."""
        return (self.size_bits() + 7) // 8


class PolarQuant:
    """Main PolarQuant quantization class.
    
    Implements the PolarQuant algorithm:
    1. Random orthogonal rotation to normalize distribution
    2. Cartesian to polar coordinate transformation
    3. Lloyd-Max quantization for radius and angles
    4. Zero metadata overhead
    """
    
    def __init__(self, config: PolarQuantConfig):
        """Initialize PolarQuant with configuration.
        
        Args:
            config: PolarQuantConfig instance
        """
        self.config = config
        self.dimension = config.dimension
        
        # Initialize rotation matrix
        if config.use_hadamard:
            self.rotation_matrix = None  # Will use FWHT
        else:
            self.rotation_matrix = random_orthogonal_matrix(
                config.dimension, seed=config.seed
            )
        
        # Compute Beta distribution parameters
        self.alpha, self.beta_param = beta_distribution_params(config.dimension)
        
        # Precompute Lloyd-Max centroids for angles
        # Angles are in [0, π] for most dimensions, [0, 2π] for last
        self.angle_centroids = compute_lloyd_max_centroids(
            self.alpha, self.beta_param, config.angle_bits
        )
        
        # For radius, we use uniform quantization (log scale)
        self.radius_levels = 2 ** config.radius_bits
        
        # Statistics for adaptive quantization
        self.radius_min = 0.0
        self.radius_max = 10.0  # Will be adjusted dynamically
        
    def _rotate(self, x: np.ndarray) -> np.ndarray:
        """Apply rotation to input vector."""
        if self.config.use_hadamard:
            from .utils import hadamard_rotation
            return hadamard_rotation(x)
        else:
            return self.rotation_matrix @ x
    
    def _inverse_rotate(self, x: np.ndarray) -> np.ndarray:
        """Apply inverse rotation."""
        if self.config.use_hadamard:
            # Hadamard is self-inverse (up to normalization)
            from .utils import hadamard_rotation
            return hadamard_rotation(x)
        else:
            return self.rotation_matrix.T @ x
    
    def _quantize_radius(self, r: float) -> Tuple[int, float]:
        """Quantize radius using log-scale uniform quantization.
        
        Args:
            r: Radius value
            
        Returns:
            Tuple of (quantized index, reconstructed radius)
        """
        if r < 1e-10:
            return 0, 0.0
        
        # Log-scale quantization for better dynamic range
        log_r = np.log(max(r, 1e-10))
        log_min, log_max = np.log(1e-3), np.log(self.radius_max)
        
        # Normalize to [0, 1]
        log_r_norm = (log_r - log_min) / (log_max - log_min)
        log_r_norm = np.clip(log_r_norm, 0, 1)
        
        # Quantize
        idx = int(log_r_norm * (self.radius_levels - 1))
        idx = min(idx, self.radius_levels - 1)
        
        # Dequantize
        log_r_recon = log_min + idx / (self.radius_levels - 1) * (log_max - log_min)
        r_recon = np.exp(log_r_recon)
        
        return idx, r_recon
    
    def _dequantize_radius(self, idx: int) -> float:
        """Dequantize radius index."""
        log_min, log_max = np.log(1e-3), np.log(self.radius_max)
        log_r = log_min + idx / (self.radius_levels - 1) * (log_max - log_min)
        return np.exp(log_r)
    
    def compress(self, x: np.ndarray) -> CompressedVector:
        """Compress a vector using PolarQuant.
        
        Args:
            x: Input vector of shape (dimension,)
            
        Returns:
            CompressedVector instance
        """
        x = np.asarray(x, dtype=np.float64)
        if len(x) != self.dimension:
            raise ValueError(f"Expected dimension {self.dimension}, got {len(x)}")
        
        # Store original norm for potential use
        original_norm = np.linalg.norm(x)
        
        # Step 1: Random rotation
        x_rotated = self._rotate(x)
        
        # Step 2: Convert to polar coordinates
        r, angles = cartesian_to_polar(x_rotated)
        
        # Step 3: Quantize radius
        radius_idx, _ = self._quantize_radius(r)
        
        # Step 4: Quantize angles
        # Map angles from [0, π] or [0, 2π] to [0, 1] for Beta distribution
        # For simplicity, we use the same quantization for all angles
        angles_normalized = angles / np.pi  # Normalize to [0, 1] approximately
        angles_normalized = np.clip(angles_normalized, 0, 1)
        
        angle_indices = lloyd_max_quantize(angles_normalized, self.angle_centroids)
        
        return CompressedVector(radius_idx, angle_indices, original_norm)
    
    def decompress(self, compressed: CompressedVector) -> np.ndarray:
        """Decompress a vector.
        
        Args:
            compressed: CompressedVector instance
            
        Returns:
            Reconstructed vector
        """
        # Step 1: Dequantize radius
        r = self._dequantize_radius(compressed.radius_idx)
        
        # Step 2: Dequantize angles
        angles = lloyd_max_dequantize(compressed.angle_indices, self.angle_centroids)
        angles = angles * np.pi  # Denormalize from [0, 1] to [0, π]
        
        # Step 3: Convert back to Cartesian
        x_rotated = polar_to_cartesian(r, angles)
        
        # Step 4: Inverse rotation
        x_reconstructed = self._inverse_rotate(x_rotated)
        
        return x_reconstructed
    
    def compression_ratio(self) -> float:
        """Calculate compression ratio.
        
        Returns:
            Ratio of original size to compressed size
        """
        # Original: dimension * 32 bits (float32)
        original_bits = self.dimension * 32
        
        # Compressed: radius_bits + (dimension-1) * angle_bits
        compressed_bits = self.config.radius_bits + (self.dimension - 1) * self.config.angle_bits
        
        return original_bits / compressed_bits
    
    def compute_error(self, x: np.ndarray, x_reconstructed: np.ndarray) -> dict:
        """Compute reconstruction error metrics.
        
        Args:
            x: Original vector
            x_reconstructed: Reconstructed vector
            
        Returns:
            Dictionary of error metrics
        """
        mse = np.mean((x - x_reconstructed) ** 2)
        rmse = np.sqrt(mse)
        
        # Cosine similarity
        norm_x = np.linalg.norm(x)
        norm_recon = np.linalg.norm(x_reconstructed)
        if norm_x > 1e-10 and norm_recon > 1e-10:
            cosine_sim = np.dot(x, x_reconstructed) / (norm_x * norm_recon)
        else:
            cosine_sim = 0.0
        
        # Relative error
        if norm_x > 1e-10:
            relative_error = np.linalg.norm(x - x_reconstructed) / norm_x
        else:
            relative_error = 0.0
        
        return {
            'mse': mse,
            'rmse': rmse,
            'cosine_similarity': cosine_sim,
            'relative_error': relative_error,
        }
    
    def save(self, path: str):
        """Save the quantizer state to file."""
        state = {
            'config': self.config,
            'rotation_matrix': self.rotation_matrix,
            'angle_centroids': self.angle_centroids,
            'radius_max': self.radius_max,
        }
        with open(path, 'wb') as f:
            pickle.dump(state, f)
    
    @classmethod
    def load(cls, path: str) -> 'PolarQuant':
        """Load a quantizer from file."""
        with open(path, 'rb') as f:
            state = pickle.load(f)
        
        pq = cls(state['config'])
        pq.rotation_matrix = state['rotation_matrix']
        pq.angle_centroids = state['angle_centroids']
        pq.radius_max = state['radius_max']
        return pq


class PolarQuantBatch:
    """Batch processing for PolarQuant.
    
    Efficiently compress/decompress multiple vectors.
    """
    
    def __init__(self, quantizer: PolarQuant):
        self.quantizer = quantizer
    
    def compress_batch(self, X: np.ndarray) -> List[CompressedVector]:
        """Compress a batch of vectors.
        
        Args:
            X: Array of shape (n_vectors, dimension)
            
        Returns:
            List of CompressedVector instances
        """
        return [self.quantizer.compress(x) for x in X]
    
    def decompress_batch(self, compressed_list: List[CompressedVector]) -> np.ndarray:
        """Decompress a batch of vectors.
        
        Args:
            compressed_list: List of CompressedVector instances
            
        Returns:
            Array of shape (n_vectors, dimension)
        """
        return np.array([self.quantizer.decompress(c) for c in compressed_list])
    
    def compute_batch_error(self, X: np.ndarray, X_reconstructed: np.ndarray) -> dict:
        """Compute error metrics for a batch.
        
        Args:
            X: Original vectors
            X_reconstructed: Reconstructed vectors
            
        Returns:
            Dictionary of aggregated error metrics
        """
        mse_list = []
        cosine_list = []
        
        for x, x_recon in zip(X, X_reconstructed):
            errors = self.quantizer.compute_error(x, x_recon)
            mse_list.append(errors['mse'])
            cosine_list.append(errors['cosine_similarity'])
        
        return {
            'mean_mse': np.mean(mse_list),
            'mean_rmse': np.mean(np.sqrt(mse_list)),
            'mean_cosine': np.mean(cosine_list),
            'min_cosine': np.min(cosine_list),
        }
