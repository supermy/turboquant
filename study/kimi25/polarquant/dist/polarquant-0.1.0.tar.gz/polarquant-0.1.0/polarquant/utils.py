"""
Utility functions for PolarQuant algorithm.

This module provides core mathematical operations including:
- Random orthogonal matrix generation
- Cartesian to polar coordinate transformation
- Lloyd-Max quantization for Beta distribution
"""

import numpy as np
from scipy.stats import beta
from typing import Tuple, Optional


def random_orthogonal_matrix(d: int, seed: Optional[int] = None) -> np.ndarray:
    """
    Generate a random orthogonal matrix using QR decomposition.
    
    The random rotation is crucial for PolarQuant as it ensures each coordinate
    follows a Beta(d/2, d/2) distribution after rotation.
    
    Args:
        d: Dimension of the matrix
        seed: Random seed for reproducibility
        
    Returns:
        d x d orthogonal matrix (R @ R.T = I)
    """
    if seed is not None:
        np.random.seed(seed)
    
    # Generate random matrix and perform QR decomposition
    A = np.random.randn(d, d)
    Q, R = np.linalg.qr(A)
    
    # Ensure determinant is 1 (proper rotation)
    if np.linalg.det(Q) < 0:
        Q[:, 0] = -Q[:, 0]
    
    return Q


def hadamard_rotation(x: np.ndarray) -> np.ndarray:
    """
    Apply Hadamard rotation to input vector.
    
    Hadamard rotation is a structured orthogonal transformation that can be
    computed efficiently in O(d log d) time using the Fast Walsh-Hadamard Transform.
    
    Args:
        x: Input vector of shape (d,)
        
    Returns:
        Rotated vector of shape (d,)
    """
    d = len(x)
    
    # Pad to power of 2 if necessary
    d_pad = 1 << (d - 1).bit_length()
    if d_pad != d:
        x_padded = np.zeros(d_pad)
        x_padded[:d] = x.copy()
    else:
        x_padded = x.copy()
    
    # Fast Walsh-Hadamard Transform
    h = 1
    while h < len(x_padded):
        for i in range(0, len(x_padded), h * 2):
            for j in range(i, i + h):
                a = x_padded[j]
                b = x_padded[j + h]
                x_padded[j] = a + b
                x_padded[j + h] = a - b
        h *= 2
    
    # Normalize by sqrt(d_pad) to preserve norm
    x_padded = x_padded / np.sqrt(d_pad)
    
    return x_padded[:d]


def cartesian_to_polar(x: np.ndarray) -> Tuple[float, np.ndarray]:
    """
    Convert Cartesian coordinates to polar coordinates.
    
    For a d-dimensional vector, returns:
    - r: radius (L2 norm)
    - angles: d-1 angles in [0, π] for the first d-2 angles and [0, 2π] for the last
    
    The transformation is:
    x_0 = r * cos(θ_0)
    x_1 = r * sin(θ_0) * cos(θ_1)
    x_2 = r * sin(θ_0) * sin(θ_1) * cos(θ_2)
    ...
    x_{d-2} = r * sin(θ_0) * ... * sin(θ_{d-3}) * cos(θ_{d-2})
    x_{d-1} = r * sin(θ_0) * ... * sin(θ_{d-3}) * sin(θ_{d-2})
    
    Args:
        x: Input vector of shape (d,)
        
    Returns:
        Tuple of (radius, angles)
    """
    d = len(x)
    
    # Compute radius
    r = np.linalg.norm(x)
    
    if r < 1e-10:
        # Zero vector case
        return 0.0, np.zeros(d - 1)
    
    # Normalize to unit sphere
    x_norm = x / r
    
    # Compute angles using recursive formula
    angles = np.zeros(d - 1)
    
    for i in range(d - 1):
        # Project remaining components
        remaining_norm = np.linalg.norm(x_norm[i:])
        if remaining_norm < 1e-10:
            angles[i] = 0.0
        else:
            # cos(θ_i) = x_i / ||x[i:]||
            cos_theta = np.clip(x_norm[i] / remaining_norm, -1.0, 1.0)
            angles[i] = np.arccos(cos_theta)
    
    # Adjust last angle based on sign of last coordinate
    if x[-1] < 0:
        angles[-1] = 2 * np.pi - angles[-1]
    
    return r, angles


def polar_to_cartesian(r: float, angles: np.ndarray) -> np.ndarray:
    """
    Convert polar coordinates back to Cartesian coordinates.
    
    Args:
        r: Radius
        angles: Array of d-1 angles
        
    Returns:
        Cartesian vector of shape (d,)
    """
    d = len(angles) + 1
    x = np.zeros(d)
    
    if r < 1e-10:
        return x
    
    # Compute sin and cos products
    sin_product = 1.0
    
    for i in range(d - 1):
        x[i] = r * sin_product * np.cos(angles[i])
        sin_product *= np.sin(angles[i])
    
    x[-1] = r * sin_product
    
    return x


def compute_lloyd_max_centroids(alpha: float, beta_param: float, 
                                 bits: int, n_iterations: int = 100) -> np.ndarray:
    """
    Compute Lloyd-Max quantization centroids for Beta distribution.
    
    The Lloyd-Max algorithm iteratively optimizes quantization boundaries
    and centroids to minimize mean squared error.
    
    Args:
        alpha: Alpha parameter of Beta distribution
        beta_param: Beta parameter of Beta distribution
        bits: Number of bits for quantization
        n_iterations: Number of Lloyd-Max iterations
        
    Returns:
        Array of centroids
    """
    n_levels = 2 ** bits
    
    # Initialize centroids uniformly in [0, 1]
    centroids = np.linspace(0, 1, n_levels)
    
    # Beta distribution PDF
    def beta_pdf(x):
        return beta.pdf(x, alpha, beta_param)
    
    # Beta distribution CDF
    def beta_cdf(x):
        return beta.cdf(x, alpha, beta_param)
    
    for _ in range(n_iterations):
        # Compute boundaries as midpoints between centroids
        boundaries = np.zeros(n_levels + 1)
        boundaries[0] = 0.0
        boundaries[-1] = 1.0
        
        for i in range(1, n_levels):
            boundaries[i] = (centroids[i - 1] + centroids[i]) / 2
        
        # Update centroids to conditional expectation
        new_centroids = np.zeros(n_levels)
        for i in range(n_levels):
            # Numerical integration for conditional expectation
            a, b = boundaries[i], boundaries[i + 1]
            
            if a >= b:
                new_centroids[i] = centroids[i]
                continue
            
            # Use Simpson's rule for integration
            n_points = 100
            x_grid = np.linspace(a, b, n_points)
            dx = (b - a) / (n_points - 1)
            
            pdf_vals = beta_pdf(x_grid)
            x_pdf_vals = x_grid * pdf_vals
            
            # Simpson's rule
            integral_x_pdf = dx / 3 * (
                x_pdf_vals[0] + 
                4 * np.sum(x_pdf_vals[1:-1:2]) + 
                2 * np.sum(x_pdf_vals[2:-2:2]) + 
                x_pdf_vals[-1]
            )
            
            integral_pdf = dx / 3 * (
                pdf_vals[0] + 
                4 * np.sum(pdf_vals[1:-1:2]) + 
                2 * np.sum(pdf_vals[2:-2:2]) + 
                pdf_vals[-1]
            )
            
            if integral_pdf > 1e-10:
                new_centroids[i] = integral_x_pdf / integral_pdf
            else:
                new_centroids[i] = (a + b) / 2
        
        centroids = new_centroids
    
    return centroids


def lloyd_max_quantize(x: np.ndarray, centroids: np.ndarray) -> np.ndarray:
    """
    Quantize values using Lloyd-Max centroids.
    
    Args:
        x: Input values in [0, 1]
        centroids: Lloyd-Max centroids
        
    Returns:
        Quantized indices
    """
    # Clip to [0, 1]
    x_clipped = np.clip(x, 0, 1)
    
    # Find nearest centroid for each value
    indices = np.argmin(np.abs(x_clipped[:, None] - centroids[None, :]), axis=1)
    
    return indices.astype(np.uint32)


def lloyd_max_dequantize(indices: np.ndarray, centroids: np.ndarray) -> np.ndarray:
    """
    Dequantize indices back to values using centroids.
    
    Args:
        indices: Quantized indices
        centroids: Lloyd-Max centroids
        
    Returns:
        Reconstructed values
    """
    return centroids[indices]


def beta_distribution_params(d: int) -> Tuple[float, float]:
    """
    Compute Beta distribution parameters for rotated coordinates.
    
    After random rotation, each coordinate follows Beta(d/2, d/2) distribution
    when projected to [0, 1] from [-1, 1].
    
    Args:
        d: Dimension of the vector
        
    Returns:
        Tuple of (alpha, beta) parameters
    """
    alpha = d / 2
    beta_param = d / 2
    return alpha, beta_param
