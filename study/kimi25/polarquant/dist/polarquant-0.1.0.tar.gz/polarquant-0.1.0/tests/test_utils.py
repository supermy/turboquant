"""
Unit tests for utility functions in PolarQuant.
"""

import unittest
import numpy as np
from polarquant.utils import (
    random_orthogonal_matrix,
    hadamard_rotation,
    cartesian_to_polar,
    polar_to_cartesian,
    compute_lloyd_max_centroids,
    lloyd_max_quantize,
    lloyd_max_dequantize,
    beta_distribution_params,
)


class TestRandomOrthogonalMatrix(unittest.TestCase):
    """Test random orthogonal matrix generation."""
    
    def test_orthogonality(self):
        """Test that generated matrix is orthogonal."""
        d = 10
        Q = random_orthogonal_matrix(d, seed=42)
        
        # Check Q @ Q.T = I
        identity = Q @ Q.T
        np.testing.assert_array_almost_equal(identity, np.eye(d), decimal=10)
    
    def test_determinant(self):
        """Test that determinant is +/- 1."""
        d = 5
        Q = random_orthogonal_matrix(d, seed=42)
        det = np.linalg.det(Q)
        self.assertAlmostEqual(abs(det), 1.0, places=10)
    
    def test_reproducibility(self):
        """Test that same seed produces same matrix."""
        d = 8
        Q1 = random_orthogonal_matrix(d, seed=123)
        Q2 = random_orthogonal_matrix(d, seed=123)
        np.testing.assert_array_equal(Q1, Q2)
    
    def test_different_seeds(self):
        """Test that different seeds produce different matrices."""
        d = 8
        Q1 = random_orthogonal_matrix(d, seed=1)
        Q2 = random_orthogonal_matrix(d, seed=2)
        self.assertFalse(np.allclose(Q1, Q2))


class TestHadamardRotation(unittest.TestCase):
    """Test Hadamard rotation."""
    
    def test_norm_preservation(self):
        """Test that Hadamard rotation preserves norm."""
        d = 16
        x = np.random.randn(d)
        x_rotated = hadamard_rotation(x)
        
        np.testing.assert_almost_equal(
            np.linalg.norm(x), np.linalg.norm(x_rotated), decimal=10
        )
    
    def test_linearity(self):
        """Test that Hadamard rotation is linear."""
        d = 8
        x1 = np.random.randn(d)
        x2 = np.random.randn(d)
        
        # Test H(a*x + b*y) = a*H(x) + b*H(y)
        a, b = 2.0, 3.0
        result1 = hadamard_rotation(a * x1 + b * x2)
        result2 = a * hadamard_rotation(x1) + b * hadamard_rotation(x2)
        
        np.testing.assert_array_almost_equal(result1, result2, decimal=10)
    
    def test_power_of_two(self):
        """Test with power-of-2 dimensions."""
        for d in [2, 4, 8, 16, 32]:
            x = np.random.randn(d)
            x_rotated = hadamard_rotation(x)
            self.assertEqual(len(x_rotated), d)
    
    def test_non_power_of_two(self):
        """Test with non-power-of-2 dimensions."""
        d = 10
        x = np.random.randn(d)
        x_rotated = hadamard_rotation(x)
        self.assertEqual(len(x_rotated), d)


class TestPolarCoordinateTransform(unittest.TestCase):
    """Test Cartesian to polar coordinate transformation."""
    
    def test_roundtrip_2d(self):
        """Test 2D roundtrip conversion."""
        x = np.array([3.0, 4.0])
        r, angles = cartesian_to_polar(x)
        x_recon = polar_to_cartesian(r, angles)
        
        np.testing.assert_array_almost_equal(x, x_recon, decimal=10)
    
    def test_roundtrip_3d(self):
        """Test 3D roundtrip conversion."""
        x = np.array([1.0, 2.0, 2.0])
        r, angles = cartesian_to_polar(x)
        x_recon = polar_to_cartesian(r, angles)
        
        np.testing.assert_array_almost_equal(x, x_recon, decimal=10)
    
    def test_roundtrip_nd(self):
        """Test nD roundtrip conversion."""
        for d in [2, 4, 8, 16]:
            x = np.random.randn(d)
            r, angles = cartesian_to_polar(x)
            x_recon = polar_to_cartesian(r, angles)
            
            np.testing.assert_array_almost_equal(x, x_recon, decimal=8)
    
    def test_radius_computation(self):
        """Test that radius is correctly computed."""
        x = np.array([3.0, 4.0])
        r, _ = cartesian_to_polar(x)
        self.assertAlmostEqual(r, 5.0, places=10)
    
    def test_zero_vector(self):
        """Test handling of zero vector."""
        x = np.zeros(5)
        r, angles = cartesian_to_polar(x)
        
        self.assertEqual(r, 0.0)
        np.testing.assert_array_equal(angles, np.zeros(4))
    
    def test_unit_vector(self):
        """Test with unit vectors."""
        d = 4
        x = np.array([1.0, 0.0, 0.0, 0.0])
        r, angles = cartesian_to_polar(x)
        
        self.assertAlmostEqual(r, 1.0, places=10)


class TestLloydMaxQuantization(unittest.TestCase):
    """Test Lloyd-Max quantization."""
    
    def test_centroids_in_range(self):
        """Test that centroids are in [0, 1]."""
        alpha, beta_param = 2.0, 2.0
        bits = 4
        
        centroids = compute_lloyd_max_centroids(alpha, beta_param, bits)
        
        self.assertTrue(np.all(centroids >= 0))
        self.assertTrue(np.all(centroids <= 1))
        self.assertEqual(len(centroids), 2 ** bits)
    
    def test_quantization_dequantization(self):
        """Test quantization followed by dequantization."""
        alpha, beta_param = 2.0, 2.0
        bits = 3
        
        centroids = compute_lloyd_max_centroids(alpha, beta_param, bits)
        
        # Test values
        x = np.array([0.1, 0.3, 0.5, 0.7, 0.9])
        indices = lloyd_max_quantize(x, centroids)
        x_recon = lloyd_max_dequantize(indices, centroids)
        
        # Check that indices are valid
        self.assertTrue(np.all(indices >= 0))
        self.assertTrue(np.all(indices < 2 ** bits))
        
        # Check that reconstructed values are centroids
        for val in x_recon:
            self.assertIn(val, centroids)
    
    def test_convergence(self):
        """Test that Lloyd-Max algorithm converges."""
        alpha, beta_param = 4.0, 4.0
        bits = 4
        
        # Run with different iteration counts
        centroids_10 = compute_lloyd_max_centroids(alpha, beta_param, bits, n_iterations=10)
        centroids_100 = compute_lloyd_max_centroids(alpha, beta_param, bits, n_iterations=100)
        
        # Should be similar after sufficient iterations (check with lower precision)
        # The algorithm may need more iterations to fully converge
        np.testing.assert_array_almost_equal(centroids_10, centroids_100, decimal=1)


class TestBetaDistributionParams(unittest.TestCase):
    """Test Beta distribution parameter computation."""
    
    def test_symmetric_params(self):
        """Test that parameters are symmetric."""
        for d in [2, 4, 8, 16, 32]:
            alpha, beta_param = beta_distribution_params(d)
            self.assertEqual(alpha, beta_param)
            self.assertEqual(alpha, d / 2)
    
    def test_positive_params(self):
        """Test that parameters are positive."""
        for d in [2, 4, 8]:
            alpha, beta_param = beta_distribution_params(d)
            self.assertGreater(alpha, 0)
            self.assertGreater(beta_param, 0)


if __name__ == '__main__':
    unittest.main()
